import { 
  Phone, 
  Mail, 
  MapPin,
  Instagram,
  Linkedin,
  Facebook,
  ArrowUp
} from 'lucide-react'

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const quickLinks = [
    { name: "Início", href: "#home" },
    { name: "Serviços", href: "#services" },
    { name: "Sobre Nós", href: "#about" },
    { name: "Contato", href: "#contact" }
  ]

  const services = [
    "Gestão de Redes Sociais",
    "Design Gráfico",
    "Marketing Digital",
    "Consultoria"
  ]

  const socialLinks = [
    {
      icon: Instagram,
      name: "Instagram",
      link: "https://www.instagram.com/cepec_digital/"
    },
    {
      icon: Linkedin,
      name: "LinkedIn",
      link: "#"
    },
    {
      icon: Facebook,
      name: "Facebook",
      link: "https://www.facebook.com/graficacepec/"
    }
  ]

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center">
              <img 
                src="/src/assets/cepec-logo.png" 
                alt="CEPEC Digital Logo" 
                className="w-12 h-12 object-contain"
              />
              <div className="ml-3">
                <h3 className="text-xl font-bold">CEPEC Digital</h3>
                <p className="text-gray-400 text-sm">Marketing & Publicidade</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Especialistas em marketing digital e redes sociais. 
              Transformamos ideias em resultados digitais para o sucesso do seu negócio.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon
                return (
                  <a
                    key={index}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 transition-all duration-300"
                    aria-label={social.name}
                  >
                    <IconComponent className="w-5 h-5" />
                  </a>
                )
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold mb-6">Nossos Serviços</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <span className="text-gray-400">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6">Contato</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Phone className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400">Telefone</p>
                  <a 
                    href="tel:+244939888015"
                    className="text-white hover:text-purple-400 transition-colors"
                  >
                    +244 939 888 015
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Mail className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400">Email</p>
                  <a 
                    href="mailto:comercial@cepecdigital.com"
                    className="text-white hover:text-purple-400 transition-colors"
                  >
                    comercial@cepecdigital.com
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400">Localização</p>
                  <p className="text-white">Angola, Luanda</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 CEPEC Digital. Todos os direitos reservados.
            </p>
            
            <button
              onClick={scrollToTop}
              className="mt-4 md:mt-0 w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center hover:from-purple-700 hover:to-pink-700 transition-all duration-300"
              aria-label="Voltar ao topo"
            >
              <ArrowUp className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

