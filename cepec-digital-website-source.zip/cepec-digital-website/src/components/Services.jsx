import { Button } from '@/components/ui/button.jsx'
import { 
  Share2, 
  Palette, 
  TrendingUp, 
  Users, 
  ArrowRight,
  CheckCircle
} from 'lucide-react'

const Services = () => {
  const services = [
    {
      icon: Share2,
      title: "Gestão de Redes Sociais",
      description: "Criação de conteúdo estratégico, agendamento, monitoramento e análise de métricas para Facebook, Instagram, LinkedIn e outras plataformas.",
      benefits: [
        "Aumento de engajamento",
        "Construção de marca",
        "Geração de leads qualificados"
      ],
      color: "from-blue-500 to-purple-600"
    },
    {
      icon: Palette,
      title: "Design Gráfico",
      description: "Criação de identidade visual, logotipos, materiais impressos, posts para redes sociais e banners digitais profissionais.",
      benefits: [
        "Imagem profissional",
        "Comunicação visual eficaz",
        "Diferenciação no mercado"
      ],
      color: "from-pink-500 to-red-500"
    },
    {
      icon: TrendingUp,
      title: "Marketing Digital",
      description: "Estratégias de SEO, SEM (Google Ads), Email Marketing, Marketing de Conteúdo e Automação de Marketing para resultados mensuráveis.",
      benefits: [
        "Aumento de tráfego",
        "Leads qualificados",
        "Maior ROI"
      ],
      color: "from-green-500 to-teal-600"
    },
    {
      icon: Users,
      title: "Consultoria em Marketing Digital",
      description: "Análise de mercado, desenvolvimento de planos estratégicos personalizados, treinamento e acompanhamento especializado.",
      benefits: [
        "Direcionamento estratégico",
        "Otimização de recursos",
        "Resultados mensuráveis"
      ],
      color: "from-orange-500 to-yellow-500"
    }
  ]

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Nossos Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Soluções digitais completas para impulsionar o crescimento do seu negócio. 
            Cada serviço é personalizado para atender às suas necessidades específicas.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon
            return (
              <div 
                key={index}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 p-8 border border-gray-100"
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-16 h-16 bg-gradient-to-r ${service.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">
                      {service.title}
                    </h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {service.description}
                    </p>
                    
                    {/* Benefits */}
                    <div className="space-y-2 mb-6">
                      {service.benefits.map((benefit, benefitIndex) => (
                        <div key={benefitIndex} className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700">{benefit}</span>
                        </div>
                      ))}
                    </div>

                    <Button 
                      variant="outline" 
                      className="group hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:text-white hover:border-transparent transition-all duration-300"
                    >
                      Saiba Mais
                      <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 lg:p-12 text-center text-white">
          <h3 className="text-3xl lg:text-4xl font-bold mb-4">
            Pronto para Transformar Seu Negócio?
          </h3>
          <p className="text-xl mb-8 opacity-90">
            Entre em contato conosco e descubra como podemos ajudar a alcançar seus objetivos digitais.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-6"
            >
              Solicitar Orçamento Gratuito
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-purple-600 text-lg px-8 py-6"
            >
              Falar com Especialista
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Services

