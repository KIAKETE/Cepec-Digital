import { Button } from '@/components/ui/button.jsx'
import { 
  Target, 
  Eye, 
  Heart, 
  Award,
  Users,
  TrendingUp,
  ArrowRight
} from 'lucide-react'

const About = () => {
  const values = [
    {
      icon: Target,
      title: "Inovação",
      description: "Sempre buscamos as mais recentes tendências e tecnologias para oferecer soluções criativas e eficazes."
    },
    {
      icon: Heart,
      title: "Compromisso",
      description: "Dedicamo-nos integralmente ao sucesso dos nossos clientes, tratando cada projeto como se fosse nosso."
    },
    {
      icon: Award,
      title: "Excelência",
      description: "Mantemos os mais altos padrões de qualidade em todos os nossos serviços e entregas."
    },
    {
      icon: Users,
      title: "Parceria",
      description: "Construímos relacionamentos duradouros baseados na confiança e transparência."
    }
  ]

  const stats = [
    {
      number: "100+",
      label: "Clientes Satisfeitos",
      icon: Users
    },
    {
      number: "500%",
      label: "Aumento Médio de Engagement",
      icon: TrendingUp
    },
    {
      number: "3+",
      label: "Anos de Experiência",
      icon: Award
    },
    {
      number: "24/7",
      label: "Suporte Disponível",
      icon: Target
    }
  ]

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Sobre a CEPEC Digital
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Somos uma agência especializada em marketing digital, dedicada a transformar 
            ideias em resultados concretos para o seu negócio.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                A Paixão por Transformar no Digital
              </h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                A CEPEC Digital nasceu da paixão por conectar empresas ao seu público-alvo 
                através de estratégias digitais inovadoras. Acreditamos que cada marca tem 
                uma história única para contar, e nossa missão é amplificar essa voz no 
                mundo digital.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Com uma equipa de especialistas em marketing digital, design e estratégia, 
                oferecemos soluções personalizadas que geram resultados mensuráveis e 
                sustentáveis para o crescimento do seu negócio.
              </p>
            </div>

            <Button 
              size="lg" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              Conheça Nossa História
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>

          {/* Visual */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => {
                  const IconComponent = stat.icon
                  return (
                    <div key={index} className="text-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-gray-900">{stat.number}</div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  )
                })}
              </div>
            </div>
            
            {/* Background decoration */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-20"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full opacity-20"></div>
          </div>
        </div>

        {/* Mission, Vision, Values */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {/* Mission */}
          <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Target className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Nossa Missão</h3>
            <p className="text-gray-600 leading-relaxed">
              Potencializar marcas e negócios através de estratégias digitais inovadoras, 
              conectando empresas ao público certo no momento certo.
            </p>
          </div>

          {/* Vision */}
          <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Eye className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Nossa Visão</h3>
            <p className="text-gray-600 leading-relaxed">
              Ser referência em marketing digital, reconhecida pela excelência, 
              inovação e pelos resultados transformadores que entregamos.
            </p>
          </div>

          {/* Values Preview */}
          <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Nossos Valores</h3>
            <p className="text-gray-600 leading-relaxed">
              Inovação, compromisso, transparência, orientação a resultados e 
              parceria são os pilares que guiam todas as nossas ações.
            </p>
          </div>
        </div>

        {/* Values Detail */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => {
            const IconComponent = value.icon
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg flex items-center justify-center mb-4">
                  <IconComponent className="w-6 h-6 text-purple-600" />
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-2">{value.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default About

