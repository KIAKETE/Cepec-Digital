import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Menu, X, Phone, Mail } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center">
            <img 
              src="/src/assets/cepec-logo.png" 
              alt="CEPEC Digital Logo" 
              className="w-12 h-12 object-contain"
            />
            <div className="ml-3">
              <h1 className="text-xl font-bold text-gray-800">CEPEC Digital</h1>
              <p className="text-sm text-gray-600">Marketing & Publicidade</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-700 hover:text-purple-600 transition-colors">Início</a>
            <a href="#services" className="text-gray-700 hover:text-purple-600 transition-colors">Serviços</a>
            <a href="#about" className="text-gray-700 hover:text-purple-600 transition-colors">Sobre Nós</a>
            <a href="#contact" className="text-gray-700 hover:text-purple-600 transition-colors">Contato</a>
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Phone size={16} />
              <span>+244 939 888 015</span>
            </div>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              Solicitar Orçamento
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4 pt-4">
              <a href="#home" className="text-gray-700 hover:text-purple-600 transition-colors">Início</a>
              <a href="#services" className="text-gray-700 hover:text-purple-600 transition-colors">Serviços</a>
              <a href="#about" className="text-gray-700 hover:text-purple-600 transition-colors">Sobre Nós</a>
              <a href="#contact" className="text-gray-700 hover:text-purple-600 transition-colors">Contato</a>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Phone size={16} />
                <span>+244 939 888 015</span>
              </div>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 w-full">
                Solicitar Orçamento
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Header

